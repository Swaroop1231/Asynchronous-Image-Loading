//
//  SSObject.h
//  SDWebImgAlternative
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SSObject : NSObject
{
    
    NSString *imageURl;
}
@property(nonatomic,strong) NSString *imageURl;


@end
