//
//  SSViewController.m
//  SDWebImgAlternative
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SSViewController.h"
#import "AsynchronousFreeloader.h"
#import "JSON.h"
#import "ASIFormDataRequest.h"

@interface SSViewController ()

@end

@implementation SSViewController
@synthesize imgScrollView;
@synthesize ssobject;
@synthesize ssArray;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    //[self loadScrollView];
    
    ssArray=[[NSMutableArray alloc]init];
    [self getData];
    
    
}



-(void)getData
{
    
    NSString *urlstr=[NSString stringWithFormat:@"http://iseeksugar.com/services/getimages.php"];
    
    NSURL *mainURL=[NSURL URLWithString:urlstr];
    
    ASIFormDataRequest *request=[ASIHTTPRequest requestWithURL:mainURL];
    [request setDelegate:self];
    [request startAsynchronous];
    
    
}

- (void)requestFinished:(ASIFormDataRequest *)request
{
    
    NSError *error=[request error];
    if(!error)
    {
        
        NSString *response=[request responseString];
        
        NSArray *mainArray=[[NSArray alloc]init];
        mainArray=[response JSONValue];
        
        for (int i=0; i<[mainArray count]; i++)
        {
            
            NSMutableDictionary *mainDict=[[NSMutableDictionary alloc]init];
            mainDict=[mainArray objectAtIndex:i];
            
            ssobject=[[SSObject alloc]init];
            
            ssobject.imageURl=[mainDict valueForKey:@"thumb"];
            
            
            [ssArray addObject:ssobject];
            
            
        }
        
        
        NSLog(@"Main array count is %d",[ssArray count]);
    }
    [self loadScrollView];
    
}
- (void)requestFailed:(ASIFormDataRequest *)request
{
   
    NSLog(@"Network Error No Network Available ");
    // UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Network Error" message:@"No Network Available" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil , nil];
    // [alertView show];
    
    
}




-(void)loadScrollView
{
    int x=10;
    int y=10;
    
    for (int i=0; i<[ssArray count]; i++)
    {
        
        
        UIView *adView=[[UIView alloc]initWithFrame:CGRectMake(x, y, 60, 60)];

    UIImageView *mainImgView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
    
        [adView addSubview:mainImgView];
        
       // adView.backgroundColor=[UIColor greenColor];
    SSObject *obj=[ssArray objectAtIndex:i];
    
        NSLog(@"-----> OBJ is %@",obj.imageURl);
    
   [AsynchronousFreeloader loadImageFromLink:obj.imageURl forImageView:mainImgView withPlaceholderView:nil andContentMode:UIViewContentModeScaleToFill];
        
    [self.imgScrollView addSubview:adView];
            
        if((i+1)%3==0)
        {
            x=10;
            y=y+95;
            
        }
        else
        {
            x=x+105;
        }
        
        
        }
    

   self.imgScrollView.contentSize=CGSizeMake(self.imgScrollView.frame.size.width,y+100);
    
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
