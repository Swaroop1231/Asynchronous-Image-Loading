//
//  SSViewController.h
//  SDWebImgAlternative
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSObject.h"

@interface SSViewController : UIViewController<UIScrollViewDelegate>
{

    
    IBOutlet UIScrollView *imgScrollView;
}

@property(nonatomic,strong) IBOutlet UIScrollView *imgScrollView;
@property(nonatomic,strong) SSObject *ssobject;
@property(nonatomic,strong) NSMutableArray *ssArray;

-(void)loadScrollView;
@end
